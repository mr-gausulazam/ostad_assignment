# QA Automation Assessment

UI and API automation suite built with Playwright and JavaScript.

## What is covered

### UI Automation

- Q1: Login with `locked_out_user` and verify the locked-out message.
- Q2: Login with `standard_user`, reset App State, add three products, verify product names and final total, complete checkout, verify the order confirmation, reset App State and log out.
- Q3: Login with `performance_glitch_user`, reset App State, sort products Z to A, add the first product, verify the product name and final total, complete checkout, verify the order confirmation, reset App State and log out.

### API Automation

- Q3: Login with registered credentials and verify an authentication token is returned.
- Q4: GET user by ID and verify the expected first name and email.
- Q5: PUT a profile update and verify the returned `updatedAt` timestamp.
- Q6: PATCH one field and verify the response contains the changed field without unrelated profile fields.
- Q8: Send invalid/missing data and an unknown user ID and verify 4xx responses.

## Project structure

```text
qa-automation-assessment/
├── .github/
│   └── workflows/
│       └── playwright.yml
├── pages/
│   ├── CartPage.js
│   ├── CheckoutPage.js
│   ├── InventoryPage.js
│   └── LoginPage.js
├── test-data/
│   └── testData.js
├── tests/
│   ├── api/
│   │   ├── q3-login.spec.js
│   │   ├── q4-get-user.spec.js
│   │   ├── q5-put-user.spec.js
│   │   ├── q6-patch-user.spec.js
│   │   └── q8-bad-requests.spec.js
│   └── ui/
│       ├── q1-locked-user.spec.js
│       ├── q2-standard-checkout.spec.js
│       └── q3-performance-glitch.spec.js
├── .env.example
├── .gitignore
├── package.json
├── playwright.config.js
└── README.md
```

## Requirements

- Node.js 18+ (20 LTS recommended)
- npm

## Setup

```bash
npm install
npx playwright install
```

For ReqRes API tests, copy `.env.example` to `.env` and add the API key supplied for the assessment:

```text
REQRES_API_KEY=your_key_here
REQRES_ENV=prod
```

The API key is read from the environment and is not stored in the source code.

## Run everything

```bash
npx playwright test
```

## Run only UI

```bash
npm run test:ui
```

## Run only API

```bash
npm run test:api
```

## Run with the browser visible

```bash
npm run test:headed
```

## View the report

```bash
npm run report
```

## ReqRes authentication

The API project is configured to send the ReqRes API key through Playwright's request context. The key should remain in `.env` locally or in a GitHub Actions secret named `REQRES_API_KEY`.

`REQRES_ENV` defaults to `prod` when the workflow is used.

## GitHub Actions

A workflow is included at:

```text
.github/workflows/playwright.yml
```

Before running the workflow, add this repository secret:

```text
REQRES_API_KEY
```

Do not commit `.env` or expose the API key in the repository.

## Test data

SauceDemo credentials are public demo credentials and are kept in `test-data/testData.js`.

ReqRes test data is also kept in the same file so that the request bodies and expected values are easy to review.

## Notes about Q6

The ReqRes classic API is a mock API. The PATCH response is therefore validated against the field sent in the request and checked for the absence of unrelated profile fields. This avoids treating a mock response as a persistent database update.

## Expected deliverables

For submission, the repository contains:

1. Source code
2. Page Object Model classes
3. Test data
4. Playwright configuration
5. Environment example
6. GitHub Actions workflow
7. README with setup and execution instructions

Generated `playwright-report/`, `test-results/`, `node_modules/`, and `.env` files should not be committed.
