# Submission Checklist

Before submitting the repository:

- [ ] Run `npm install`
- [ ] Run `npx playwright install`
- [ ] Create `.env` locally with the ReqRes API key
- [ ] Run `npx playwright test`
- [ ] Check the HTML report
- [ ] Confirm all expected tests pass
- [ ] Do not commit `.env`
- [ ] Do not commit `node_modules`
- [ ] Do not commit `test-results`
- [ ] Do not commit `playwright-report` unless the assessor explicitly asks for it
- [ ] Add `REQRES_API_KEY` as a GitHub repository secret if using GitHub Actions
- [ ] Push the repository to GitHub
- [ ] Submit the GitHub repository URL
