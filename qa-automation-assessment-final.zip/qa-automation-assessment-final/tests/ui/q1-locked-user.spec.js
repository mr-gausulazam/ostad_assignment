import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage.js';
import { sauceUsers } from '../../test-data/testData.js';

test('Q1 - locked out user receives the expected error', async ({ page }) => {
  const login = new LoginPage(page);

  await login.open();
  await login.login(sauceUsers.lockedOut.username, sauceUsers.lockedOut.password);

  await expect(login.errorMessage).toContainText(
    'Sorry, this user has been locked out'
  );
});