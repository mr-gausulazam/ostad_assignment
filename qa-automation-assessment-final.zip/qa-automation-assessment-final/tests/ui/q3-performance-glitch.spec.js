import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage.js';
import { InventoryPage } from '../../pages/InventoryPage.js';
import { CartPage } from '../../pages/CartPage.js';
import { CheckoutPage } from '../../pages/CheckoutPage.js';
import { checkoutDetails, sauceUsers } from '../../test-data/testData.js';

test('Q3 - performance glitch user buys the first Z-A product', async ({ page }) => {
  const login = new LoginPage(page);
  const inventory = new InventoryPage(page);
  const cart = new CartPage(page);
  const checkout = new CheckoutPage(page);

  await login.open();
  await login.login(
    sauceUsers.performanceGlitch.username,
    sauceUsers.performanceGlitch.password
  );

  await expect(page).toHaveURL(/inventory\.html/);

  await inventory.resetAppState();
  await inventory.sortNameDescending();

  const selected = await inventory.firstProduct();
  await inventory.addFirstProduct();
  await inventory.openCart();

  expect(await cart.productNames()).toEqual([selected.name]);

  await cart.checkout();
  await checkout.fillDetails(checkoutDetails);

  expect(await checkout.productNames()).toEqual([selected.name]);
  expect(await checkout.productPrices()).toEqual([selected.price]);

  const summary = await checkout.summaryValues();

  expect(summary.subtotal).toBe(selected.price);
  expect(summary.total).toBeCloseTo(summary.subtotal + summary.tax, 2);

  await checkout.finish();

  await expect(checkout.successMessage).toBeVisible();

  await inventory.resetAppState();
  await inventory.logout();

  await expect(page).toHaveURL(/saucedemo\.com\/$/);
});