import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage.js';
import { InventoryPage } from '../../pages/InventoryPage.js';
import { CartPage } from '../../pages/CartPage.js';
import { CheckoutPage } from '../../pages/CheckoutPage.js';
import { checkoutDetails, sauceUsers } from '../../test-data/testData.js';

test('Q2 - standard user completes a three item purchase', async ({ page }) => {
  const login = new LoginPage(page);
  const inventory = new InventoryPage(page);
  const cart = new CartPage(page);
  const checkout = new CheckoutPage(page);

  await login.open();
  await login.login(sauceUsers.standard.username, sauceUsers.standard.password);

  await expect(page).toHaveURL(/inventory\.html/);

  await inventory.resetAppState();

  const products = [
    'Sauce Labs Backpack',
    'Sauce Labs Bike Light',
    'Sauce Labs Bolt T-Shirt'
  ];

  for (const product of products) {
    await inventory.addProduct(product);
  }

  await inventory.openCart();

  expect(await cart.productNames()).toEqual(products);

  await cart.checkout();
  await checkout.fillDetails(checkoutDetails);

  expect(await checkout.productNames()).toEqual(products);

  const prices = await checkout.productPrices();
  const summary = await checkout.summaryValues();
  const expectedSubtotal = Number(
    prices.reduce((sum, price) => sum + price, 0).toFixed(2)
  );

  expect(summary.subtotal).toBe(expectedSubtotal);
  expect(summary.total).toBeCloseTo(summary.subtotal + summary.tax, 2);

  await checkout.finish();

  await expect(checkout.successMessage).toBeVisible();

  await inventory.resetAppState();
  await inventory.logout();

  await expect(page).toHaveURL(/saucedemo\.com\/$/);
});