import { test, expect } from '@playwright/test';
import { reqresData } from '../../test-data/testData.js';

test('Q3 - login with registered credentials and capture auth token', async ({ request }) => {
  const response = await request.post('/login', {
    data: reqresData.login
  });

  expect(response.status()).toBe(200);

  const body = await response.json();

  expect(body).toHaveProperty('token');
  expect(typeof body.token).toBe('string');
  expect(body.token.length).toBeGreaterThan(0);
});