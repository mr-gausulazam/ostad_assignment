import { test, expect } from '@playwright/test';
import { reqresData } from '../../test-data/testData.js';

test('Q6 - PATCH one field and verify only the requested field was updated', async ({ request }) => {
  const response = await request.patch(`/users/${reqresData.user.id}`, {
    data: reqresData.patch
  });

  expect(response.status()).toBe(200);

  const body = await response.json();

  expect(body.job).toBe(reqresData.patch.job);
  expect(body.updatedAt).toBeTruthy();

  const returnedFields = Object.keys(body);
  expect(returnedFields).toEqual(
    expect.arrayContaining(['job', 'updatedAt'])
  );
  expect(returnedFields).not.toContain('name');
  expect(returnedFields).not.toContain('email');
});