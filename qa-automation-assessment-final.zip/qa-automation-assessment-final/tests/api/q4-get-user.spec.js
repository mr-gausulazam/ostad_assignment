import { test, expect } from '@playwright/test';
import { reqresData } from '../../test-data/testData.js';

test('Q4 - GET user and verify name and email', async ({ request }) => {
  const response = await request.get(`/users/${reqresData.user.id}`);

  expect(response.status()).toBe(200);

  const body = await response.json();

  expect(body.data.id).toBe(reqresData.user.id);
  expect(body.data.first_name).toBe(reqresData.user.firstName);
  expect(body.data.email).toBe(reqresData.user.email);
});