import { test, expect } from '@playwright/test';
import { reqresData } from '../../test-data/testData.js';

test('Q5 - PUT updated profile and verify updatedAt', async ({ request }) => {
  const response = await request.put(`/users/${reqresData.user.id}`, {
    data: reqresData.profile
  });

  expect(response.status()).toBe(200);

  const body = await response.json();

  expect(body.name).toBe(reqresData.profile.name);
  expect(body.job).toBe(reqresData.profile.job);
  expect(body.updatedAt).toBeTruthy();
  expect(Number.isNaN(Date.parse(body.updatedAt))).toBe(false);
});