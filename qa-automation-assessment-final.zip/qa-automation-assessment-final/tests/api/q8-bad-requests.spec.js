import { test, expect } from '@playwright/test';
import { reqresData } from '../../test-data/testData.js';

test.describe('Q8 - bad requests', () => {
  test('invalid login credentials return a 4xx response', async ({ request }) => {
    const response = await request.post('/login', {
      data: reqresData.badLogin
    });

    expect(response.status()).toBeGreaterThanOrEqual(400);
    expect(response.status()).toBeLessThan(500);
  });

  test('missing password returns a 4xx response', async ({ request }) => {
    const response = await request.post('/login', {
      data: {
        email: reqresData.login.email
      }
    });

    expect(response.status()).toBeGreaterThanOrEqual(400);
    expect(response.status()).toBeLessThan(500);
  });

  test('unknown user id returns a 4xx response', async ({ request }) => {
    const response = await request.get('/users/9999');

    expect(response.status()).toBeGreaterThanOrEqual(400);
    expect(response.status()).toBeLessThan(500);
  });
});