export const sauceUsers = {
  standard: {
    username: 'standard_user',
    password: 'secret_sauce'
  },
  lockedOut: {
    username: 'locked_out_user',
    password: 'secret_sauce'
  },
  performanceGlitch: {
    username: 'performance_glitch_user',
    password: 'secret_sauce'
  }
};

export const checkoutDetails = {
  firstName: 'Gausul',
  lastName: 'Azam',
  postalCode: '1212'
};

export const reqresData = {
  login: {
    email: 'eve.holt@reqres.in',
    password: 'cityslicka'
  },
  user: {
    id: 2,
    firstName: 'Janet',
    email: 'janet.weaver@reqres.in'
  },
  profile: {
    name: 'Janet Weaver',
    job: 'QA Engineer'
  },
  patch: {
    job: 'Senior QA Engineer'
  },
  badLogin: {
    email: 'eve.holt@reqres.in',
    password: 'not_the_right_password'
  }
};