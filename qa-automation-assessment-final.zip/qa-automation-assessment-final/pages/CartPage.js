export class CartPage {
  constructor(page) {
    this.page = page;
    this.items = page.locator('.cart_item');
    this.names = page.locator('.inventory_item_name');
    this.prices = page.locator('.inventory_item_price');
    this.checkoutButton = page.getByRole('button', { name: 'Checkout' });
  }

  async productNames() {
    return this.names.allTextContents();
  }

  async productPrices() {
    const values = await this.prices.allTextContents();
    return values.map(value => Number(value.replace('$', '')));
  }

  async checkout() {
    await this.checkoutButton.click();
  }
}