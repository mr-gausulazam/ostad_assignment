export class CheckoutPage {
  constructor(page) {
    this.page = page;
    this.firstNameInput = page.getByRole('textbox', { name: 'First Name' });
    this.lastNameInput = page.getByRole('textbox', { name: 'Last Name' });
    this.postalCodeInput = page.getByRole('textbox', { name: 'Zip/Postal Code' });
    this.continueButton = page.getByRole('button', { name: 'Continue' });
    this.finishButton = page.getByRole('button', { name: 'Finish' });
    this.names = page.locator('.inventory_item_name');
    this.prices = page.locator('.inventory_item_price');
    this.subtotal = page.locator('.summary_subtotal_label');
    this.tax = page.locator('.summary_tax_label');
    this.total = page.locator('.summary_total_label');
    this.successMessage = page.getByText('Thank you for your order!');
  }

  async fillDetails(details) {
    await this.firstNameInput.fill(details.firstName);
    await this.lastNameInput.fill(details.lastName);
    await this.postalCodeInput.fill(details.postalCode);
    await this.continueButton.click();
  }

  async productNames() {
    return this.names.allTextContents();
  }

  async productPrices() {
    const values = await this.prices.allTextContents();
    return values.map(value => Number(value.replace('$', '')));
  }

  async summaryValues() {
    const subtotalText = await this.subtotal.innerText();
    const taxText = await this.tax.innerText();
    const totalText = await this.total.innerText();

    return {
      subtotal: Number(subtotalText.replace('Item total: $', '')),
      tax: Number(taxText.replace('Tax: $', '')),
      total: Number(totalText.replace('Total: $', ''))
    };
  }

  async finish() {
    await this.finishButton.click();
  }
}