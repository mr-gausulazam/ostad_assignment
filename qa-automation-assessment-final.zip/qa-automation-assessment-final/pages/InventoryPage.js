export class InventoryPage {
  constructor(page) {
    this.page = page;
    this.menuButton = page.getByRole('button', { name: 'Open Menu' });
    this.resetLink = page.getByRole('link', { name: 'Reset App State' });
    this.logoutLink = page.getByRole('link', { name: 'Logout' });
    this.sortControl = page.locator('[data-test="product-sort-container"]');
    this.productCards = page.locator('.inventory_item');
    this.productNames = page.locator('.inventory_item_name');
    this.productPrices = page.locator('.inventory_item_price');
    this.cartLink = page.getByRole('link', { name: /cart/i });
  }

  async openMenu() {
    await this.menuButton.click();
  }

  async resetAppState() {
    await this.openMenu();
    await this.resetLink.click();
  }

  async logout() {
    await this.openMenu();
    await this.logoutLink.click();
  }

  async sortNameDescending() {
    await this.sortControl.selectOption('za');
  }

  async addProduct(name) {
    const card = this.productCards.filter({ hasText: name });
    await card.getByRole('button', { name: /Add to cart/i }).click();
  }

  async addFirstProduct() {
    await this.productCards.first().getByRole('button', { name: /Add to cart/i }).click();
  }

  async firstProduct() {
    const name = (await this.productNames.first().innerText()).trim();
    const priceText = (await this.productPrices.first().innerText()).trim();
    return {
      name,
      price: Number(priceText.replace('$', ''))
    };
  }

  async openCart() {
    await this.cartLink.click();
  }
}